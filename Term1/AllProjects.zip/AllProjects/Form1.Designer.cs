﻿namespace AllProjects
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.header = new System.Windows.Forms.Panel();
            this.btnDash = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.btnCalc = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnTemp = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dashPanel = new System.Windows.Forms.Panel();
            this.lblDashTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.calcPanel = new System.Windows.Forms.Panel();
            this.lblCalcTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tmpPanel = new System.Windows.Forms.Panel();
            this.lblTmpTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.header.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.dashPanel.SuspendLayout();
            this.calcPanel.SuspendLayout();
            this.tmpPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.btnTemp);
            this.panel1.Controls.Add(this.btnCalc);
            this.panel1.Controls.Add(this.btnDash);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 39);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(265, 553);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(241, 90);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // header
            // 
            this.header.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.header.Controls.Add(this.pictureBox2);
            this.header.Controls.Add(this.bunifuCustomLabel1);
            this.header.Dock = System.Windows.Forms.DockStyle.Top;
            this.header.Location = new System.Drawing.Point(0, 0);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(996, 39);
            this.header.TabIndex = 1;
            // 
            // btnDash
            // 
            this.btnDash.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnDash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnDash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDash.BorderRadius = 0;
            this.btnDash.ButtonText = "Dashboard";
            this.btnDash.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDash.DisabledColor = System.Drawing.Color.Gray;
            this.btnDash.ForeColor = System.Drawing.Color.Black;
            this.btnDash.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDash.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnDash.Iconimage")));
            this.btnDash.Iconimage_right = null;
            this.btnDash.Iconimage_right_Selected = null;
            this.btnDash.Iconimage_Selected = null;
            this.btnDash.IconMarginLeft = 0;
            this.btnDash.IconMarginRight = 0;
            this.btnDash.IconRightVisible = true;
            this.btnDash.IconRightZoom = 0D;
            this.btnDash.IconVisible = true;
            this.btnDash.IconZoom = 90D;
            this.btnDash.IsTab = true;
            this.btnDash.Location = new System.Drawing.Point(0, 113);
            this.btnDash.Name = "btnDash";
            this.btnDash.Normalcolor = System.Drawing.Color.Transparent;
            this.btnDash.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnDash.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnDash.selected = true;
            this.btnDash.Size = new System.Drawing.Size(265, 48);
            this.btnDash.TabIndex = 2;
            this.btnDash.Text = "Dashboard";
            this.btnDash.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDash.Textcolor = System.Drawing.Color.White;
            this.btnDash.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDash.Click += new System.EventHandler(this.btnDash_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(12, 9);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(133, 18);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Vision Application";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(960, 9);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(25, 25);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.header;
            this.bunifuDragControl1.Vertical = true;
            // 
            // btnCalc
            // 
            this.btnCalc.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnCalc.BackColor = System.Drawing.Color.Transparent;
            this.btnCalc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCalc.BorderRadius = 0;
            this.btnCalc.ButtonText = "Calculator";
            this.btnCalc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCalc.DisabledColor = System.Drawing.Color.Gray;
            this.btnCalc.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCalc.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCalc.Iconimage")));
            this.btnCalc.Iconimage_right = null;
            this.btnCalc.Iconimage_right_Selected = null;
            this.btnCalc.Iconimage_Selected = null;
            this.btnCalc.IconMarginLeft = 0;
            this.btnCalc.IconMarginRight = 0;
            this.btnCalc.IconRightVisible = true;
            this.btnCalc.IconRightZoom = 0D;
            this.btnCalc.IconVisible = true;
            this.btnCalc.IconZoom = 90D;
            this.btnCalc.IsTab = true;
            this.btnCalc.Location = new System.Drawing.Point(0, 167);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Normalcolor = System.Drawing.Color.Transparent;
            this.btnCalc.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnCalc.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnCalc.selected = false;
            this.btnCalc.Size = new System.Drawing.Size(265, 48);
            this.btnCalc.TabIndex = 3;
            this.btnCalc.Text = "Calculator";
            this.btnCalc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCalc.Textcolor = System.Drawing.Color.White;
            this.btnCalc.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnTemp
            // 
            this.btnTemp.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnTemp.BackColor = System.Drawing.Color.Transparent;
            this.btnTemp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTemp.BorderRadius = 0;
            this.btnTemp.ButtonText = "Temp Convertor";
            this.btnTemp.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTemp.DisabledColor = System.Drawing.Color.Gray;
            this.btnTemp.Iconcolor = System.Drawing.Color.Transparent;
            this.btnTemp.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnTemp.Iconimage")));
            this.btnTemp.Iconimage_right = null;
            this.btnTemp.Iconimage_right_Selected = null;
            this.btnTemp.Iconimage_Selected = null;
            this.btnTemp.IconMarginLeft = 0;
            this.btnTemp.IconMarginRight = 0;
            this.btnTemp.IconRightVisible = true;
            this.btnTemp.IconRightZoom = 0D;
            this.btnTemp.IconVisible = true;
            this.btnTemp.IconZoom = 90D;
            this.btnTemp.IsTab = true;
            this.btnTemp.Location = new System.Drawing.Point(0, 221);
            this.btnTemp.Name = "btnTemp";
            this.btnTemp.Normalcolor = System.Drawing.Color.Transparent;
            this.btnTemp.OnHovercolor = System.Drawing.Color.Transparent;
            this.btnTemp.OnHoverTextColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.btnTemp.selected = false;
            this.btnTemp.Size = new System.Drawing.Size(265, 48);
            this.btnTemp.TabIndex = 4;
            this.btnTemp.Text = "Temp Convertor";
            this.btnTemp.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTemp.Textcolor = System.Drawing.Color.White;
            this.btnTemp.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTemp.Click += new System.EventHandler(this.btnTemp_Click);
            // 
            // dashPanel
            // 
            this.dashPanel.Controls.Add(this.lblDashTitle);
            this.dashPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dashPanel.Location = new System.Drawing.Point(265, 39);
            this.dashPanel.Name = "dashPanel";
            this.dashPanel.Size = new System.Drawing.Size(731, 553);
            this.dashPanel.TabIndex = 2;
            // 
            // lblDashTitle
            // 
            this.lblDashTitle.AutoSize = true;
            this.lblDashTitle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDashTitle.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDashTitle.Location = new System.Drawing.Point(35, 32);
            this.lblDashTitle.Name = "lblDashTitle";
            this.lblDashTitle.Size = new System.Drawing.Size(86, 18);
            this.lblDashTitle.TabIndex = 0;
            this.lblDashTitle.Text = "Dashboard";
            // 
            // calcPanel
            // 
            this.calcPanel.Controls.Add(this.lblCalcTitle);
            this.calcPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calcPanel.Location = new System.Drawing.Point(265, 39);
            this.calcPanel.Name = "calcPanel";
            this.calcPanel.Size = new System.Drawing.Size(731, 553);
            this.calcPanel.TabIndex = 3;
            this.calcPanel.Visible = false;
            // 
            // lblCalcTitle
            // 
            this.lblCalcTitle.AutoSize = true;
            this.lblCalcTitle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCalcTitle.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCalcTitle.Location = new System.Drawing.Point(35, 32);
            this.lblCalcTitle.Name = "lblCalcTitle";
            this.lblCalcTitle.Size = new System.Drawing.Size(78, 18);
            this.lblCalcTitle.TabIndex = 0;
            this.lblCalcTitle.Text = "Calculator";
            // 
            // tmpPanel
            // 
            this.tmpPanel.Controls.Add(this.lblTmpTitle);
            this.tmpPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tmpPanel.Location = new System.Drawing.Point(265, 39);
            this.tmpPanel.Name = "tmpPanel";
            this.tmpPanel.Size = new System.Drawing.Size(731, 553);
            this.tmpPanel.TabIndex = 4;
            this.tmpPanel.Visible = false;
            // 
            // lblTmpTitle
            // 
            this.lblTmpTitle.AutoSize = true;
            this.lblTmpTitle.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTmpTitle.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTmpTitle.Location = new System.Drawing.Point(35, 32);
            this.lblTmpTitle.Name = "lblTmpTitle";
            this.lblTmpTitle.Size = new System.Drawing.Size(153, 18);
            this.lblTmpTitle.TabIndex = 0;
            this.lblTmpTitle.Text = "Tempature Converter";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(46)))), ((int)(((byte)(59)))));
            this.ClientSize = new System.Drawing.Size(996, 592);
            this.Controls.Add(this.tmpPanel);
            this.Controls.Add(this.calcPanel);
            this.Controls.Add(this.dashPanel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.header);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.header.ResumeLayout(false);
            this.header.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.dashPanel.ResumeLayout(false);
            this.dashPanel.PerformLayout();
            this.calcPanel.ResumeLayout(false);
            this.calcPanel.PerformLayout();
            this.tmpPanel.ResumeLayout(false);
            this.tmpPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel header;
        private Bunifu.Framework.UI.BunifuFlatButton btnDash;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuFlatButton btnTemp;
        private Bunifu.Framework.UI.BunifuFlatButton btnCalc;
        private System.Windows.Forms.Panel dashPanel;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDashTitle;
        private System.Windows.Forms.Panel calcPanel;
        private Bunifu.Framework.UI.BunifuCustomLabel lblCalcTitle;
        private System.Windows.Forms.Panel tmpPanel;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTmpTitle;
    }
}

