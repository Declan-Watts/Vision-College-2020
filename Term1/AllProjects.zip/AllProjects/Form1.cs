﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AllProjects
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Close(); //Closes Program
        }

        private void btnDash_Click(object sender, EventArgs e)
        {
            dashPanel.Visible = true;
            calcPanel.Visible = false;
            tmpPanel.Visible = false;
            dashPanel.BringToFront();
            dashPanel.Enabled = true;
            calcPanel.Enabled = false;
            tmpPanel.Enabled = false;
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            dashPanel.Visible = false;
            calcPanel.Visible = true;
            tmpPanel.Visible = false;
            calcPanel.BringToFront();
            dashPanel.Enabled = false;
            calcPanel.Enabled = true;
            tmpPanel.Enabled = false;
        }

        private void btnTemp_Click(object sender, EventArgs e)
        {
            dashPanel.Visible = false;
            calcPanel.Visible = false;
            tmpPanel.Visible = true;
            tmpPanel.BringToFront();
            dashPanel.Enabled = false;
            calcPanel.Enabled = true;
            tmpPanel.Enabled = true;
        }
    }
}
